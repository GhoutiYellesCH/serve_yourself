import 'package:flutter/material.dart';

class Historiquepage extends StatefulWidget {
  const Historiquepage({super.key});

  @override
  State<Historiquepage> createState() => _HistoriquepageState();
}

class _HistoriquepageState extends State<Historiquepage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Historique'),
      ),
      body: const Center(
        child: Text('Historique'),
      ),
      
    );
  }
}