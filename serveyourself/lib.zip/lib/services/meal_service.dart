import 'package:serveyourself/api/meal_api.dart';
import 'package:serveyourself/models/meal.dart';

class MealService {
  final MealApi mealApi = MealApi();

  Future<List<Meal>> getMeals() async {
    final mealsJson = await mealApi.fetchMeals();
    return mealsJson.map((json) => Meal.fromJson(json)).toList();
  }
}
