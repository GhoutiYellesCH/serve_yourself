import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:io';

class MealApi {
  // Make the baseUrl configurable
  final String baseUrl;

  // Constructor with optional baseUrl parameter
  MealApi({this.baseUrl = 'https://www.themealdb.com/api/json/v1/1/'});

  // Check if API is reachable
  Future<bool> isApiReachable() async {
    try {
      final response = await http
          .get(Uri.parse(baseUrl))
          .timeout(const Duration(seconds: 5));
      return response.statusCode == 200;
    } on SocketException {
      // Handle no internet connection
      return false;
    } on FormatException {
      // Handle invalid URI format
      return false;
    } on http.ClientException {
      // Handle URI that doesn't exist or is not reachable
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<List<dynamic>> fetchMeals() async {
    try {
      final response = await http.get(Uri.parse(baseUrl));
      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        throw Exception('Failed to load meals: Status ${response.statusCode}');
      }
    } on SocketException {
      throw Exception('No internet connection');
    } on FormatException {
      throw Exception('Invalid URI format: $baseUrl');
    } on http.ClientException catch (e) {
      throw Exception('URI error: ${e.message}');
    } catch (e) {
      throw Exception('Unexpected error: $e');
    }
  }

  // Add a meal to the API
  Future<Map<String, dynamic>> addMeal(Map<String, dynamic> mealData) async {
    try {
      final response = await http.post(
        Uri.parse(baseUrl),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(mealData),
      );

      if (response.statusCode == 201) {
        return json.decode(response.body);
      } else {
        throw Exception('Failed to add meal: Status ${response.statusCode}');
      }
    } on SocketException {
      throw Exception('No internet connection');
    } on FormatException {
      throw Exception('Invalid URI format: $baseUrl');
    } catch (e) {
      throw Exception('Unexpected error: $e');
    }
  }
}
